1. Зарегистрируйся на https://railway.app
2. Создай новый проект -> Upload ZIP
3. Залей этот архив
4. Укажи Start Command: python bot.py
5. Укажи переменную среды: YOUR_BOT_TOKEN_HERE
6. Наслаждайся работающим ботом!
